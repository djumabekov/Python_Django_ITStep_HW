from task2 import task2
from task1 import task1

if __name__ == '__main__':
   # Задание 1
   task1()

   # Задание 2
   # task2()
