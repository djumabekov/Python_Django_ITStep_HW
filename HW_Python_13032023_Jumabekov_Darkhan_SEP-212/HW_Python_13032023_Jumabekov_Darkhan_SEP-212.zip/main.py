from Automobile import Automobile
from Book import Book
from Stadium import Stadium


if __name__ == '__main__':
    # Задание №1
    # automobile1 = Automobile('A6', 2011, 'Audi', 2.8, 'black', 30_000)
    # print(automobile1)
    #
    # automobile1.input()
    # print(automobile1)

    # Задание №2
    # book1 = Book(name='Война и мир', year='2020', publisher='Москва', genre='Роман-эпопея', author='Лев Толстой', price='10_000')
    # print(book1)
    #
    # book1.input()
    # print(book1)

    # Задание №3
    stadium1 = Stadium(name='Astana Arena', date='16.07.2010', country='Kazakhstan', city='Astana', capacity=30_000)
    print(stadium1)
    stadium1.input()
    print(stadium1)
