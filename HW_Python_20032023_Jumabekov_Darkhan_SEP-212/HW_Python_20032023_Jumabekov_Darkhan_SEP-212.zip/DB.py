import sqlite3
import sqlite3.dbapi2

from Product import Product


class DB(object):
    __conn: sqlite3.Connection
    __cursor: sqlite3.Cursor

    def __init__(self, db_name):
        try:
            self.__conn = sqlite3.connect(f'{db_name}.sqlite3')
            self.__cursor = self.__conn.cursor()
            self.__create_table()
        except sqlite3.DatabaseError as e:
            print('Exception: ', e)


    def __create_table(self):
        create_sql = '''
            CREATE TABLE if not exists Products
            (
              Id             INTEGER   primary key autoincrement  NOT NULL,
              Name           VARCHAR(30) NOT NULL,
              Manufacturer   VARCHAR(30) NOT NULL,
              Price          DECIMAL(2)  DEFAULT(1),
              Count          INT         DEFAULT(1),
              Description    VARCHAR(30)
            );
            CREATE UNIQUE INDEX if not exists IdxProducts ON Products (Id);
            '''
        try:
            with self.__conn:
                self.__cursor.executescript(create_sql)
        except sqlite3.DatabaseError as e:
            print('Exception: ', e)

    def insert(self, product: Product):
        sql_insert = "INSERT INTO Products (Name, Manufacturer, Price, Count, Description)\
                        VALUES(?, ?, ?, ?, ?);"
        try:
            with self.__conn:
                self.__cursor.execute(sql_insert, (product.name, product.manufacturer,\
                     product.price, product.count, product.description))
                self.__conn.commit()
        except sqlite3.DatabaseError as e:
            print('Exception: ', e)

    def __get_data(self, sql_get, params)->list:
        try:
            with self.__conn:
                self.__cursor.execute(sql_get, params)
                data = self.__cursor.fetchall()
                return data
        except sqlite3.DatabaseError as e:
            print('Exception: ', e)
            return None

    def getProductsByPrice(self, from_price: float, to_price: float)->list:
        sql_get = "SELECT * FROM Products WHERE Price BETWEEN ? AND ?"
        params = (from_price, to_price)
        return self.__get_data(sql_get, params)

    def getProductByName(self, name: str)->list:
        sql_get = "SELECT * FROM Products WHERE Name LIKE ?"
        params = (f'%{name}%',)
        return self.__get_data(sql_get, params)

    def getProductByManufacturer(self, manufacturer: str)->list:
        sql_get = "SELECT * FROM Products WHERE Manufacturer LIKE ?"
        params = (f'%{manufacturer}%',)
        return self.__get_data(sql_get, params)

    def sortProductsByName(self) -> list:
        sql_get = "SELECT * FROM Products ORDER BY Name ASC"
        params = ()
        return self.__get_data(sql_get, params)

    def sortProductsByPrice(self) -> list:
        sql_get = "SELECT * FROM Products ORDER BY Price ASC"
        params = ()
        return self.__get_data(sql_get, params)

    def delete(self, id: int):
        sql_get = "DELETE FROM Products WHERE id=?"
        params = (id,)
        return self.__get_data(sql_get, params)

    def readOne(self, product: Product):
        sql_get = "SELECT * FROM Products WHERE Name=? AND Manufacturer=? AND Price=? AND Count=? AND Description=?;"
        params = (product.name, product.manufacturer, product.price, product.count, product.description)
        return self.__get_data(sql_get, params)

    def readAll(self):
        sql_get = "SELECT * FROM Products;"
        params = ()
        return self.__get_data(sql_get, params)

    def getById(self, id):
        sql_get = "SELECT * FROM Products WHERE Id=?;"
        params = (id,)
        return self.__get_data(sql_get, params)
