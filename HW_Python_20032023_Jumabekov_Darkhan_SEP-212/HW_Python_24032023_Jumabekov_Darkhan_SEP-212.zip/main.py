from task2 import task2

if __name__ == '__main__':
   # Задание 1
   task2()
